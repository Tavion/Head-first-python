from distutils.core import setup
setup(name='nester',
      version='1.0.0',
      py_modules=['nester'],
      author='Tavion',
      author_email='foliages96@outlook.com',
      description='A simple printer of nested lists',
      )

